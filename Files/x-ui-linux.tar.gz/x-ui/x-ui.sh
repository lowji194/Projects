# Được viết bởi Nolimit-key
while true $x != "ok"
do
if [[ "$(grep -c "Ubuntu" /etc/issue.net)" = "1" ]]; then
system=$(cut -d' ' -f1 /etc/issue.net)
system+=$(echo ' ')
system+=$(cut -d' ' -f2 /etc/issue.net |awk -F "." '{print $1}')
elif [[ "$(grep -c "Debian" /etc/issue.net)" = "1" ]]; then
system=$(cut -d' ' -f1 /etc/issue.net)
system+=$(echo ' ')
system+=$(cut -d' ' -f3 /etc/issue.net)
else
system=$(cut -d' ' -f1 /etc/issue.net)
fi







clear
echo -e "               \033[0;34m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
echo -e "               \E[45;1;37m                    MENU X-UI                     \E[0m"
echo -e "               \033[0;34m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"


echo -e "                    \033[1;31m[\033[1;36m1\033[1;31m] \033[1;37m• \033[1;33mXem trạng thái x-ui \033[1;31m
                    [\033[1;36m2\033[1;31m] \033[1;37m• \033[1;33mBật x-ui \033[1;31m
                    [\033[1;36m3\033[1;31m] \033[1;37m• \033[1;33mTắt x-ui \033[1;31m
                    [\033[1;36m4\033[1;31m] \033[1;37m• \033[1;33mXem nhật ký \033[1;31m
                    [\033[1;36m5\033[1;31m] \033[1;37m• \033[1;33mThay đổi cổng (port) của x-ui \033[1;31m
                    [\033[1;36m6\033[1;31m] \033[1;37m• \033[1;33mĐặt lại tên tài khoản và mật khẩu \033[1;31m
                    [\033[1;36m7\033[1;31m] \033[1;37m• \033[1;33mKhôi phục cài đặt gốc \033[1;31m
                    [\033[1;36m0\033[1;31m] \033[1;37m• \033[1;33mThoát menu \033[1;32m<\033[1;33m<\033[1;31m<\033[1;31m"
echo ""
echo -e "               \033[0;34m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"

echo ""
echo ""
echo -ne "\033[1;32m Nhập số : \033[1;37m"; read x

case "$x" in 
   1 | 01)
   clear
   systemctl status x-ui
   echo ""
   echo -ne "Nhấn phím bất kì để quay lại \033[1;32mMENU!\033[0m"; read
   ;;
   2 | 02)
   clear
   systemctl restart x-ui
   echo -e "\033[1;31mĐã bật thành công !\033[0m"
   echo -ne "Nhấn phím bất kì để quay lại \033[1;32mMENU!\033[0m"; read
   ;;
   3 | 03)
   clear
   systemctl stop x-ui
   echo -e "\033[1;31mĐã tắt x-ui !\033[0m"
   echo -ne "Nhấn phím bất kì để quay lại \033[1;32mMENU!\033[0m"; read
   ;;
   4 | 04)
   clear
   journalctl -u x-ui.service -e --no-pager -f
   echo -ne "Nhấn phím bất kì để quay lại \033[1;32mMENU!\033[0m"; read
   ;;
   5 | 05)
   clear
   echo -n -e "Nhập số cổng [1-65535]: " && read port
   /usr/local/x-ui/x-ui setting -port ${port}
   echo ""
   echo -e "\033[1;31mĐã đổi port thành \033[1;32m${port}\033[0m\033[0m"
   echo -ne "Nhấn phím bất kì để quay lại \033[1;32mMENU!\033[0m"; read
   ;;
   6 | 06)
   clear
   /usr/local/x-ui/x-ui setting -username admin -password admin
   echo -e "\033[1;31mTên tài khoản và mật khẩu đã được đổi thành \033[1;32madmin\033[0m\033[0m"
   echo -ne "Nhấn phím bất kì để quay lại \033[1;32mMENU!\033[0m"; read
   ;;
   7 | 07)
   clear
   /usr/local/x-ui/x-ui setting -reset
   echo -e "\033[1;31mĐã khôi phục cấu hình thành công !\033[0m"
   echo -ne "Nhấn phím bất kì để quay lại \033[1;32mMENU!\033[0m"; read
   ;;
   0 | 00)
   echo -e "\033[1;31mĐang thoát menu ...\033[0m"
   sleep 1
   clear
   exit;
   ;;
   *)
   echo -e "\n\033[1;31mSố bạn nhập không đúng !\033[0m"
   sleep 2
esac
done
}
menu
#fim
